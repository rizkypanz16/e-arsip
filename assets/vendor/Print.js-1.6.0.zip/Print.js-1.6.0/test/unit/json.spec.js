import Json from '../../src/js/json'

describe('Json', () => {
  it('has a method named print', () => {
    expect(typeof Json.print).toBe('function')
  })
})
